/*
 * FunCaptcha proof-of-work interceptor (MAIN world) — GPU offload + recon.
 *
 * Arkose runs its enforcement pow (the sha512 nonce search) inside a Web Worker:
 * the page posts {type:"start", data:{seed, startingNonce, targetHashData:[...]}}
 * to the worker, the worker W()-transforms the seed, splits it into per-target
 * chunks, brute-forces crypto.subtle.digest("SHA-512", chunk+nonce) until each
 * hash meets its target, splices the nonce counts back, W()-transforms again, and
 * posts the answer back. The brute force is the ONLY slow part; the transforms are
 * cheap. The avelor GPU pow-server solves exactly that brute (seed+target_hex ->
 * nonce) in a few ms.
 *
 * The clean offload = replace the worker: run the W() transform in JS to get the
 * real chunks, brute on the GPU, splice, transform, post the answer. That needs
 * the worker's exact message I/O, so THIS build is stage 1: capture the live pow
 * I/O (worker script URL, start message, reply shape) and prove the GPU roundtrip
 * works from inside the arkose frame. Once the reply format is confirmed from the
 * logs, the injection (post synthetic answer + cancel the real grind) is wired in
 * at applyGpuAnswer() below.
 *
 * Every hook is wrapped in try/catch and returns the original result untouched, so
 * it can never break the real solve — worst case it logs and no-ops.
 */
(() => {
  "use strict";

  // Localhost pow-server for the first test. CORS is permissive on the server, and
  // http://127.0.0.1 is a "potentially trustworthy" origin, so a direct fetch from
  // this https frame is allowed. Point this at the vast box later.
  const POW_SERVER = "http://127.0.0.1:8099";
  const TAG = "[pow]";
  // DEBUG gates ALL console output (and the recon/shadow tap). Off in production so
  // the console reveals nothing about how the offload works. User-facing status is
  // the on-screen pill instead. Flip to true only for local debugging.
  const DEBUG = true;
  const log = DEBUG ? (...a) => { try { console.log(TAG, ...a); } catch (_) {} } : () => {};
  const warn = DEBUG ? (...a) => { try { console.warn(TAG, ...a); } catch (_) {} } : () => {};
  // Native Worker captured before we replace self.Worker, so our compute worker is
  // created with the real ctor (not our Proxy).
  const NativeWorker = self.Worker;
  const perf = () => (self.performance && performance.now()) || 0;
  // Shadow mode: compute the GPU answer alongside Arkose's real worker and COMPARE
  // against the observed /pows/split + /pows/check, without replacing anything. When
  // it matches, the port is proven and we flip to live replacement.
  let lastShadow = null;

  // LIVE offload: replace Arkose's pow worker with our own that solves on the GPU.
  // false = shadow/recon only (safe, compares but doesn't replace). true = live.
  const ENABLE_OFFLOAD = true;
  // Pacing: the GPU solve is ~10ms. The REPORTED executionTime stays consistent
  // (scanned/rate, so the payload looks like a real solve), but the actual wall-clock
  // wait is just PACE_TOTAL_MS spread across the splits — every block we hit was the
  // missing targetHashData, never the timing, so we keep this small. 0 = instant
  // (fastest, most bot-obvious); raise it if Arkose ever starts timing the worker.
  const PACE_TOTAL_MS = 0;
  // Cap the REPORTED per-split executionTime. A very hard target's scanned/rate can be
  // many minutes, which Arkose rejects as an invalid request; the real worker never
  // reports beyond ~22s, so clamp there.
  const EXEC_CAP_MS = 22000;
  const rnd = () => { try { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] / 4294967296; } catch (_) { return 0.5; } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // --- server reachability -------------------------------------------------------
  // Only replace Arkose's worker when the pow-server is actually reachable; otherwise
  // leave the real worker in place so the captcha still solves (just slower) instead
  // of failing. serverReachable: null = unknown, true/false = last ping result.
  let serverReachable = null;
  let pinging = false;
  async function pingServer() {
    if (pinging) return; // don't stack pings
    pinging = true;
    const was = serverReachable;
    try { await powCall("/", "GET", null); serverReachable = true; if (was !== true) log("ping OK · server reachable"); }
    catch (e) { serverReachable = false; if (was !== false) warn("ping FAILED · server unreachable:", e && e.message); }
    finally { pinging = false; }
  }

  // --- on-screen status ---------------------------------------------------------
  // The pow runs in the Arkose enforcement iframe, which is destroyed the instant the
  // pow finishes — so a pill drawn HERE would vanish immediately. Post the status up
  // to the top page instead, where funcaptcha-pow-pill.js renders the themed pill so
  // it survives. state: "solving" | "ok" | "err".
  function powUI(state) {
    try {
      const ui = state === "ok" ? "done" : state === "err" ? "error" : "solving";
      (window.top || window).postMessage({ __avlrPowUI: ui }, "*");
    } catch (_) {}
  }

  // --- bridge to the extension service worker -----------------------------------
  // This runs in the MAIN world (to patch Worker), so its fetch to localhost is PNA-
  // blocked; an isolated fetch would be CORS-blocked (the gateway sends no CORS headers).
  // The service worker's fetch bypasses BOTH — the same path the image solver uses
  // (content -> background -> fetch). We relay: postMessage -> isolated bridge -> Port ->
  // SW fetch -> back. This side only sends {path, method, body}; the SW holds the URL.
  // Keys are __avelorPow / __avelorPowResp — MUST match the bridge exactly.
  const _pending = new Map();
  let _seq = 0;
  self.addEventListener("message", (e) => {
    try {
      const d = e && e.data;
      if (!d || d.__avelorPowResp !== true) return;
      const cb = _pending.get(d.id);
      if (!cb) return;
      _pending.delete(d.id);
      cb(d);
    } catch (_) {}
  });
  // powCall resolves to the response body TEXT, or rejects on a transport/HTTP error.
  function powCall(path, method, body) {
    return new Promise((resolve, reject) => {
      const id = ++_seq;
      _pending.set(id, (d) => (d.ok ? resolve(d.data) : reject(new Error(d.error || ("pow HTTP " + d.status)))));
      try { self.postMessage({ __avelorPow: true, id, path, method: method || "POST", body: body || null }, "*"); }
      catch (e) { _pending.delete(id); reject(e); return; }
      setTimeout(() => { if (_pending.has(id)) { _pending.delete(id); reject(new Error("pow bridge timeout (is the SW/bridge loaded?)")); } }, 15000);
    });
  }

  // --- GPU roundtrip ------------------------------------------------------------

  // solveRound offloads a set of {seed, target_hex} splits to the pow-server (via the
  // SW bridge) and returns the nonce per split (chained start_nonce, matching the Go
  // engine).
  // Arkose's worker brute-forces uncapped, so we do too: send an effectively-
  // unlimited scan (JS-safe max int; the server's saturating_add handles it). The GPU
  // stops at the match, so easy splits stay instant; only a genuinely hard target
  // scans further. Prevents false 422s on higher-difficulty fingerprints.
  const MAX_SCAN = Number.MAX_SAFE_INTEGER;
  async function solveRound(splits, startNonce) {
    const t0 = (self.performance && performance.now()) || 0;
    // Gateway endpoint: POST /v2/pow, same body as the standalone server's /solve_round,
    // but a wrapped response: {errorId, nonces?, status?, errorCode?}. errorId!=0 or a
    // missing/short nonces array (e.g. status:"no_nonce") -> treat as a failure so the
    // caller falls back to the browser worker.
    const txt = await powCall("/v2/pow", "POST", JSON.stringify({ splits, start_nonce: (startNonce | 0) || 0, max_scan: MAX_SCAN }));
    const j = JSON.parse(txt);
    if (!j || j.errorId !== 0 || !Array.isArray(j.nonces) || j.nonces.length !== splits.length) {
      throw new Error("pow: " + (j && (j.errorCode || j.status || "bad response")));
    }
    const ms = (perf() - t0).toFixed(1);
    log("GPU solved", splits.length, "split(s) in", ms + "ms · nonces", j.nonces);
    return j.nonces;
  }

  // --- ports of compute.go helpers ----------------------------------------------
  function utf16leB64(s) {
    const bytes = new Uint8Array(s.length * 2);
    for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); bytes[2 * i] = c & 0xff; bytes[2 * i + 1] = (c >> 8) & 0xff; }
    let bin = ""; for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }
  function splitChunks(f, n) {
    if (n <= 0) return [];
    const b = Math.floor((f.length + n - 1) / n);
    if (b * n < f.length) f = f.slice(0, b * n);
    const out = [];
    for (let s = 0; s < f.length - 1; s += b) {
      if (s === n - 1) out.push(f.slice(s));
      else out.push(f.slice(s, Math.min(s + b, f.length)));
    }
    return out;
  }
  function spliceNonceMap(aStr, attempts) {
    let e = "{";
    for (let i = 0; i < attempts.length; i++) { if (i > 0) e += ","; e += '"' + i + '":' + attempts[i]; }
    e += "}";
    if (aStr.length >= 2 && aStr[aStr.length - 1] === "]") {
      if (aStr === "[]") return "[" + e + "]";
      return aStr.slice(0, -1) + "," + e + "]";
    }
    return "[" + e + "]";
  }

  // --- W() transform via a same-origin compute worker ---------------------------
  // Arkose's seed transform is proprietary, so we RUN its real worker script (the
  // /powseq/ URL) in our own worker and drive it as a pure transform: feed a start
  // message, hook JSON.stringify to grab the transformed seed array the script
  // stringifies, and abort (throw) before it brute-forces. Mirrors compute.go's
  // transform().
  const _cwByUrl = new Map();
  function computeWorkerSource(seqUrl) {
    return '"use strict";\n(()=>{\n' +
      '  const _add=self.addEventListener.bind(self), _post=self.postMessage.bind(self);\n' +
      '  let ark=null;\n' +
      '  _add("message",(e)=>{\n' +
      '    const d=e&&e.data; if(!d||d.__cw!==true) return;\n' +
      '    const env={type:"start",data:{type:1,itimeout:75000,seed:JSON.parse(d.seed),startingNonce:0,targetHashData:[{targetHashData:"' + "0".repeat(128) + '"}]}};\n' +
      '    let cap=null, strCount=0, arrCount=0, err=null, done=false;\n' +
      '    const _str=JSON.stringify;\n' +
      '    JSON.stringify=function(v){ strCount++; if(Array.isArray(v)){ arrCount++; if(cap===null){ try{cap=_str(v);}catch(_){} } } return _str.apply(JSON,arguments); };\n' +
      '    let subOrig=null;\n' +
      '    const finish=()=>{ if(done)return; done=true; JSON.stringify=_str; try{ if(subOrig) crypto.subtle.digest=subOrig; }catch(_){}\n' +
      '      _post({__cwResp:true,id:d.id,result:cap,ok:cap!=null,error:cap!=null?null:(err||"no array captured"),dbg:{ark:!!ark,strCount,arrCount}}); };\n' +
      '    try{ if(self.crypto&&crypto.subtle&&crypto.subtle.digest){ subOrig=crypto.subtle.digest.bind(crypto.subtle);\n' +
      '      crypto.subtle.digest=function(){ if(cap!=null){ finish(); return Promise.reject(new Error("halt")); } return subOrig.apply(crypto.subtle,arguments); }; } }catch(_){}\n' +
      '    try{ const r = ark ? ark({data:env}) : null; if(r&&typeof r.then==="function"){ r.then(finish,()=>finish()); } }catch(ex){ if(cap==null) err=String(ex&&ex.message||ex); }\n' +
      '    setTimeout(finish, 1500);\n' +
      '  });\n' +
      '  self.addEventListener=function(t,f){ if(t==="message"){ ark=f; return; } return _add(t,f); };\n' +
      '  try{ Object.defineProperty(self,"onmessage",{configurable:true,set(f){ark=f;},get(){return ark;}}); }catch(_){}\n' +
      '  try{ importScripts(' + JSON.stringify(seqUrl) + '); _post({__cwReady:true}); }\n' +
      '  catch(ex){ _post({__cwReady:false,error:String(ex&&ex.message||ex)}); }\n' +
      '})();';
  }
  function getComputeWorker(seqUrl) {
    let cw = _cwByUrl.get(seqUrl);
    if (cw) return cw;
    const blob = new Blob([computeWorkerSource(seqUrl)], { type: "text/javascript" });
    const w = new NativeWorker(URL.createObjectURL(blob));
    log("compute worker: blob worker created, importScripts", seqUrl.slice(0, 55));
    const pend = new Map();
    let seq2 = 0;
    w.addEventListener("message", (e) => {
      const d = e && e.data;
      if (!d) return;
      if (d.__cwReady !== undefined) { if (!d.__cwReady) warn("compute worker load failed:", d.error); else log("compute worker ready"); return; }
      if (d.__cwResp === true) { const cb = pend.get(d.id); if (cb) { pend.delete(d.id); cb(d); } }
    });
    cw = {
      call(seedJson) {
        return new Promise((resolve, reject) => {
          const id = ++seq2;
          pend.set(id, (d) => resolve(d)); // resolve full response (result + ok + dbg)
          w.postMessage({ __cw: true, id, seed: seedJson });
          setTimeout(() => { if (pend.has(id)) { pend.delete(id); reject(new Error("transform timeout")); } }, 4000);
        });
      },
    };
    _cwByUrl.set(seqUrl, cw);
    return cw;
  }

  // computePow is the whole offload: run Arkose's W() on the seed (compute worker),
  // GPU-brute the chunks, splice the nonce counts, run W() again → the finalTransform.
  // Returns {attempts, finalTransform} — attempts[i] = Arkose's split "result".
  async function computePow(pow, seqUrl) {
    const cw = getComputeWorker(seqUrl);
    const r1 = await cw.call(JSON.stringify(pow.raw.seed));
    if (!r1.ok) throw new Error("W(seed): " + r1.error + " dbg=" + JSON.stringify(r1.dbg));
    const aStr = r1.result;
    const chunks = splitChunks(utf16leB64(aStr), pow.targets.length);
    if (chunks.length !== pow.targets.length) throw new Error("chunk count " + chunks.length + " != targets " + pow.targets.length);
    const nonces = await solveRound(chunks.map((c, i) => ({ seed: c, target_hex: pow.targets[i] })), pow.startingNonce);
    const attempts = nonces.map((n) => n + 1);
    const r2 = await cw.call(spliceNonceMap(aStr, attempts));
    if (!r2.ok) throw new Error("W(seed2): " + r2.error + " dbg=" + JSON.stringify(r2.dbg));
    return { attempts, finalTransform: JSON.parse(r2.result) };
  }

  // runShadow computes our GPU answer for a pow start and stashes it for comparison
  // against Arkose's real /pows/split + /pows/check. Never touches the real solve.
  async function runShadow(pow, seqUrl) {
    try {
      const t0 = perf();
      const { attempts, finalTransform } = await computePow(pow, seqUrl);
      lastShadow = { attempts, finalTransform };
      log("shadow computed in", (perf() - t0).toFixed(1) + "ms · results", attempts);
      log("shadow OURS finalTransform FULL:", JSON.stringify(finalTransform));
    } catch (e) {
      warn("shadow failed:", e && e.message);
    }
  }

  // makeFakeWorker returns a Worker-shaped object that replaces Arkose's pow worker.
  // It mimics the real worker's message protocol: emits {type:"loaded"} on creation,
  // and on the {type:"start"} message it GPU-solves, then paces out one
  // {type:"split_done", result} per split and a final {type:"done", finalTransform}.
  // Arkose's page code turns those into /pows/split + /pows/check with our values.
  function makeFakeWorker(seqUrl) {
    const listeners = [];
    let onmsg = null, onerr = null;
    let real = null; // Arkose's real worker, spun up only if the GPU offload fails
    const emit = (data) => {
      const ev = { data };
      log("fake: emit", data && data.type, "· onmsg?", !!onmsg, "· listeners", listeners.length);
      try { if (onmsg) onmsg(ev); } catch (_) {}
      for (const l of listeners.slice()) { try { l(ev); } catch (_) {} }
    };

    // Fallback: the offload failed, so create Arkose's real worker and let the BROWSER
    // solve the pow normally. Forward the original start to it and pipe its replies back
    // to the page — but drop its "loaded" (the page already got ours and posted start).
    function fallbackToReal(startMsg) {
      try {
        log("fallback: creating REAL Arkose worker for browser solve");
        real = new NativeWorker(seqUrl);
        real.onmessage = (e) => {
          try {
            const d = e && e.data;
            log("fallback: real worker msg ·", d && d.type);
            if (d && d.type === "loaded") return; // page already past the loaded step
            if (d && d.type === "done") powUI("ok");
            emit(d);
          } catch (_) {}
        };
        real.onerror = (e) => { warn("fallback: real worker ERROR", e && (e.message || e.filename)); powUI("err", 2500); try { if (onerr) onerr(e); } catch (_) {} };
        real.postMessage(startMsg);
        log("fallback: posted start to real worker");
      } catch (e) {
        warn("fallback worker failed:", e && e.message);
        powUI("err", 2500);
        try { if (onerr) onerr({ message: String((e && e.message) || e) }); } catch (_) {}
      }
    }

    const fake = {
      postMessage(msg) {
        const pow0 = extractPow(msg);
        log("fake: Arkose posted ·", pow0 ? "START(ok)" : "start(extractPow FAILED)", "· raw:", (() => { try { return JSON.stringify(msg).slice(0, 400); } catch (_) { return String(msg); } })());
        if (real) { try { real.postMessage(msg); } catch (_) {} return; } // already fell back
        const pow = pow0;
        if (!pow) { fallbackToReal(msg); return; } // can't parse this variant → let the browser solve
        (async () => {
          try {
            powUI("solving");
            const { attempts, finalTransform } = await computePow(pow, seqUrl);
            // Metrics mirror compute.go: rate ~143-149, per-split scanned = attempts[i] -
            // prev (chained), executionTime = scanned/rate, capped so a very hard target
            // can't report an implausible multi-minute time (Arkose 400s that). Actual
            // wall-clock wait = PACE_TOTAL_MS spread across splits.
            const dwell = Math.max(Math.round(PACE_TOTAL_MS / attempts.length), 0);
            let prev = pow.startingNonce, total = 0, rateSum = 0;
            for (let i = 0; i < attempts.length; i++) {
              const scanned = Math.max(attempts[i] - prev, 1);
              prev = attempts[i];
              const hashRate = 143 + (attempts[i] % 7);
              const executionTime = Math.min(Math.max(Math.round(scanned / hashRate), 1), EXEC_CAP_MS);
              rateSum += hashRate;
              if (dwell > 0) await sleep(dwell);
              total += executionTime;
              emit({ type: "split_done", data: { splitNum: i, hashRate, executionTime, result: attempts[i] } });
            }
            const hashRate = rateSum / attempts.length;
            // done also carries targetHashData — {iterations, targetHash} per split — which
            // the enforcement reads to build the /pows/check result[] array.
            const targetHashData = attempts.map((a, i) => ({ iterations: a, targetHash: pow.targets[i] }));
            emit({ type: "done", data: { hashRate, time: total, finalTransform, targetHashData } });
            // Post "solved" immediately — this frame gets torn down right after done, so
            // any delay here would die before it sends. The main-page pill enforces the
            // minimum "solving" display time instead (it survives the teardown).
            powUI("ok");
          } catch (e) {
            // GPU offload failed — hand the ORIGINAL start to the real worker so the
            // browser solves it (slow but works). Pill stays "solving" until it finishes.
            warn("offload failed, falling back to browser worker:", e && e.message);
            fallbackToReal(msg);
          }
        })();
      },
      addEventListener(t, f) { log("fake: Arkose addEventListener", t); if (t === "message") { listeners.push(f); sendLoaded(); } },
      removeEventListener(t, f) { const i = listeners.indexOf(f); if (i >= 0) listeners.splice(i, 1); },
      terminate() { log("fake: Arkose terminate()"); try { if (real) real.terminate(); } catch (_) {} },
      set onmessage(f) { log("fake: Arkose set onmessage"); onmsg = f; sendLoaded(); },
      get onmessage() { return onmsg; },
      set onerror(f) { onerr = f; },
      get onerror() { return onerr; },
    };
    // Emit "loaded" only AFTER Arkose has registered a handler (set onmessage or
    // addEventListener) — otherwise, if we emit at setTimeout(0) before the handler is
    // wired (as happens in WebView2), the loaded event is lost and Arkose waits forever.
    let loadedSent = false;
    function sendLoaded() {
      if (loadedSent) return;
      loadedSent = true;
      setTimeout(() => { log("fake: emitting loaded (after handler registered)"); emit({ type: "loaded", data: {} }); }, 0);
    }
    // Fallback: if Arkose never registers a handler (unexpected), still emit once.
    setTimeout(sendLoaded, 50);
    return fake;
  }

  // inspectPowReq compares Arkose's actual /pows submissions to our shadow result.
  function inspectPowReq(url, txt) {
    if (/\/pows\/(split|check)/i.test(url)) log("inspectPowReq", /check/i.test(url) ? "check" : "split", "· lastShadow?", !!lastShadow, "· txt?", typeof txt, (txt && txt.length) || 0);
    if (!lastShadow || !txt) return;
    let b = null;
    try { b = JSON.parse(txt); } catch (e) { warn("compare: could not parse", /check/i.test(url) ? "check" : "split", "body:", e && e.message); return; }
    try {
      if (/\/pows\/split/i.test(url) && b.split_num != null) {
        const ours = lastShadow.attempts[b.split_num];
        log("compare split", b.split_num, "· arkose", b.result, "· ours", ours, ours === b.result ? "✓ MATCH" : "✗ MISMATCH");
      } else if (/\/pows\/check/i.test(url) && b.transform) {
        const ark = JSON.stringify(b.transform);
        const our = JSON.stringify(lastShadow.finalTransform);
        log("compare TRANSFORM", ark === our ? "✓ MATCH" : "✗ MISMATCH", "· arkose len", ark.length, "· ours len", our.length);
        if (ark !== our) {
          log("  arkose:", ark.slice(0, 200));
          log("  ours:  ", our.slice(0, 200));
          // also compare per-entry to localize the first differing split.
          try {
            for (let i = 0; i < Math.max(b.transform.length, lastShadow.finalTransform.length); i++) {
              const a = JSON.stringify(b.transform[i]), o = JSON.stringify(lastShadow.finalTransform[i]);
              if (a !== o) { log("  first diff at entry", i, "· arkose", (a || "").slice(0, 120), "· ours", (o || "").slice(0, 120)); break; }
            }
          } catch (_) {}
        }
      }
    } catch (e) { warn("compare error:", e && e.message); }
  }

  // Ping on load (short delay so the isolated bridge's listener is up) and keep it
  // fresh, so the Worker hook knows whether to offload or fall back. A transient early
  // failure (bridge still cold) just means the next tick flips serverReachable true.
  setTimeout(pingServer, 150);
  setInterval(pingServer, 15000);

  // extractPow pulls {seed, startingNonce, targets[]} from a worker "start"
  // message in whatever shape Arkose uses (data may be the envelope or its .data;
  // targetHashData entries may be strings or {targetHashData}/{target_hash}).
  function extractPow(msg) {
    try {
      let d = msg;
      if (d && d.data && typeof d.data === "object") d = d.data;
      if (!d || typeof d !== "object") return null;
      const thd = d.targetHashData || d.target_hash_data;
      if (!Array.isArray(thd) || thd.length === 0) return null;
      const targets = thd
        .map((x) => (typeof x === "string" ? x : x && (x.targetHashData || x.target_hash || x.hash)))
        .filter((s) => typeof s === "string" && s.length >= 32);
      if (!targets.length) return null;
      return { seed: d.seed, startingNonce: (d.startingNonce | 0) || 0, targets, raw: d };
    } catch (_) { return null; }
  }

  // applyGpuAnswer: STAGE 2 stub. Once the worker reply format is known (from the
  // "worker->main reply" logs below), this rebuilds the answer with GPU nonces and
  // posts it back to the page as the worker's message, cancelling the real grind.
  // Left inert for now so the real solve is never corrupted during recon.
  // function applyGpuAnswer(worker, pow, nonces) { /* TODO from captured format */ }

  // --- Worker hook: capture pow start + reply, fire the GPU roundtrip -----------
  try {
    const RealWorker = self.Worker;
    if (typeof RealWorker === "function") {
      const Wrapped = new Proxy(RealWorker, {
        construct(Target, args) {
          let url = "";
          try { url = String(args && args[0]); } catch (_) {}
          // The pow worker URL encodes the variant:
          //   /powseq/<id>/target/<n>.js  = type 1, exact-target-hash search — GPU-solvable.
          //   /powseq/<id>/leading/<n>.js = type 0, leading-zeros/difficulty search — the
          //     gateway/GPU can't do this, so leave Arkose's own worker in place (browser
          //     solves it natively; no fake worker, no fallback delay).
          const isPowWorker = /\/powseq\//i.test(url);
          const isTarget = /\/powseq\/[^?#]*\/target\//i.test(url);
          // Offload the target variant only, and only when the server isn't confirmed down.
          // First challenge (serverReachable null) still offloads: a broken path times out
          // and makeFakeWorker falls back to the browser worker — bounded, no infinite pow.
          if (ENABLE_OFFLOAD && serverReachable !== false && isTarget) {
            log("OFFLOAD: replacing Arkose pow worker (target variant) · serverReachable?", serverReachable, "·", url.slice(0, 60));
            return makeFakeWorker(url);
          }
          if (isPowWorker) {
            warn("NOT offloading ·", isTarget ? ("target, but serverReachable=" + serverReachable) : "type-0 leading (not GPU-solvable)", "→ browser solves");
          }
          const w = Reflect.construct(Target, args);
          // Shadow/recon (compare our GPU answer to the real worker) is DEBUG-only; in
          // production the real worker is left completely untouched.
          if (DEBUG) {
            try {
              const realPost = w.postMessage.bind(w);
              w.postMessage = function (message) {
                try { const pow = extractPow(message); if (pow) runShadow(pow, url); } catch (_) {}
                return realPost.apply(this, arguments);
              };
            } catch (_) {}
          }
          return w;
        },
      });
      // Preserve prototype/statics so instanceof and Worker.* keep working.
      try { Object.defineProperty(Wrapped, "prototype", { value: RealWorker.prototype }); } catch (_) {}
      self.Worker = Wrapped;
    }
  } catch (_) {}

  // The /pows/* network tap + error capture are DEBUG-only recon (they read/log the
  // pow flow). Off in production — nothing about the mechanism reaches the console.
  if (DEBUG) {
    const isPow = (u) => { try { return /\/pows\/(setup|started|split|check)/i.test(String(u)); } catch (_) { return false; } };
    const logPow = (tagn, u, txt) => { try { if (txt) log(tagn, String(u).replace(/^https?:\/\/[^/]+/, ""), "·", String(txt).slice(0, 400)); } catch (_) {} };
    try {
      const of = self.fetch;
      if (typeof of === "function") {
        self.fetch = function (input, init) {
          const url = (input && input.url) || input;
          try { if (isPow(url) && init && init.body) { logPow("POW req", url, init.body); inspectPowReq(String(url), init.body); } } catch (_) {}
          const p = of.apply(this, arguments);
          try { if (isPow(url)) p.then((res) => { try { res.clone().text().then((t) => logPow("POW res", url, t), () => {}); } catch (_) {} return res; }).catch(() => {}); } catch (_) {}
          return p;
        };
      }
    } catch (_) {}
    try {
      const XP = self.XMLHttpRequest && self.XMLHttpRequest.prototype;
      if (XP) {
        const oOpen = XP.open, oSend = XP.send;
        XP.open = function (m, u) { try { this.__pow_url = u; } catch (_) {} return oOpen.apply(this, arguments); };
        XP.send = function (b) {
          try {
            if (isPow(this.__pow_url)) {
              if (b) { logPow("POW req", this.__pow_url, b); inspectPowReq(String(this.__pow_url), b); }
              this.addEventListener("load", function () { try { logPow("POW res", this.__pow_url, this.responseText); } catch (_) {} });
            }
          } catch (_) {}
          return oSend.apply(this, arguments);
        };
      }
    } catch (_) {}
  }

  log("pow interceptor installed");
})();
