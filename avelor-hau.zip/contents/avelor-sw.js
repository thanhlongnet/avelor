/*
 * Avelor service worker wrapper.
 *
 * Loads the existing solver background bundle UNCHANGED, then adds a pow fetch handler.
 * The fetch runs here in the SW (extension origin + host_permissions) — the ONE context
 * that bypasses BOTH CORS and Private Network Access, so it reaches the local gateway even
 * though the gateway sends no CORS headers. (An isolated content-script fetch is CORS-gated
 * in MV3; a MAIN-world fetch is PNA-blocked. This is exactly how the image solver reaches
 * the gateway — content script -> background -> fetch.)
 *
 * Uses a dedicated Port (onConnect "avelor-pow"), NOT onMessage, so the existing bundle's
 * own onMessage listeners can't intercept it. Registered BEFORE importing the bundle.
 */
const __AVELOR_POW_SERVER = "http://127.0.0.1:6968";

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "avelor-pow") return;
  port.onMessage.addListener((msg) => {
    if (!msg || msg.id == null) return;
    const method = msg.method || "POST";
    const init = { method };
    if (method !== "GET" && msg.body != null) {
      init.headers = { "content-type": "application/json" };
      init.body = msg.body;
    }
    fetch(__AVELOR_POW_SERVER + (msg.path || ""), init)
      .then((r) => r.text().then((t) => { try { port.postMessage({ id: msg.id, ok: r.ok, status: r.status, data: t }); } catch (_) {} }))
      .catch((e) => { try { port.postMessage({ id: msg.id, ok: false, error: String((e && e.message) || e) }); } catch (_) {} });
  });
});

try {
  importScripts("background_165.bundle.js");
} catch (e) {
  console.error("[avelor-sw] failed to load background bundle:", e);
}
