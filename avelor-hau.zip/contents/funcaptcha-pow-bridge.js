/*
 * FunCaptcha pow bridge (ISOLATED world).
 *
 * The MAIN-world interceptor can't fetch the gateway itself (PNA blocks its localhost
 * fetch). An isolated fetch would be CORS-blocked (the gateway sends no CORS headers). So
 * this bridge relays to the SERVICE WORKER, whose fetch bypasses both CORS and PNA — the
 * same path the image solver uses (content -> background -> fetch).
 *
 * A named Port is used (not sendMessage) so the existing bundle's onMessage listeners
 * can't eat our messages. Re-created if the SW recycles.
 *
 * Message keys MUST match the interceptor exactly: __avelorPow / __avelorPowResp.
 *
 * Page -> bridge:  window.postMessage({__avelorPow:true, id, path, method, body})
 * bridge -> SW:    port.postMessage({id, path, method, body})
 * SW -> bridge:    {id, ok, status, data} | {id, ok:false, error}
 * bridge -> page:  window.postMessage({__avelorPowResp:true, id, ok, status, data, error})
 */
(() => {
  "use strict";

  let port = null;
  const pending = new Map();

  function connect() {
    try {
      port = chrome.runtime.connect({ name: "avelor-pow" });
      port.onMessage.addListener((resp) => {
        try {
          if (!resp || resp.id == null) return;
          const cb = pending.get(resp.id);
          if (cb) { pending.delete(resp.id); cb(resp); }
        } catch (_) {}
      });
      port.onDisconnect.addListener(() => { port = null; });
    } catch (_) { port = null; }
  }

  window.addEventListener("message", (e) => {
    try {
      const d = e && e.data;
      if (!d || d.__avelorPow !== true) return;
      const id = d.id;
      const fail = (error) => { try { window.postMessage({ __avelorPowResp: true, id, ok: false, error }, "*"); } catch (_) {} };
      const track = () => pending.set(id, (resp) => { try { window.postMessage({ __avelorPowResp: true, id, ok: !!resp.ok, status: resp.status, data: resp.data, error: resp.error }, "*"); } catch (_) {} });

      if (!port) connect();
      if (!port) return fail("bridge: could not connect to background");

      track();
      try {
        port.postMessage({ id, path: d.path, method: d.method, body: d.body });
      } catch (ex) {
        pending.delete(id);
        connect();
        if (port) { track(); try { port.postMessage({ id, path: d.path, method: d.method, body: d.body }); return; } catch (_) {} }
        fail(String((ex && ex.message) || ex));
      }
    } catch (_) {}
  }, false);
})();
