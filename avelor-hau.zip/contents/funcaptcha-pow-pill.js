/*
 * PoW status pill — MAIN PAGE renderer.
 *
 * The pow runs inside the Arkose enforcement iframe, which is torn down the moment
 * the pow finishes — so a pill drawn in that frame vanishes instantly. Instead the
 * pow interceptor (in the frame) posts its status up to window.top, and THIS script,
 * running on the top page, renders the pill so it survives and is actually visible.
 *
 * Styled to exactly match the captcha solver's #captcha-message pill (same gradient,
 * Nunito Sans, shimmer/spin animations, top-center placement, done/error states).
 */
(() => {
  "use strict";
  const ID = "avlr-pow-msg";
  const STYLE_ID = "avlr-pow-style";

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const st = document.createElement("style");
    st.id = STYLE_ID;
    st.textContent =
      "@keyframes fs-in{from{opacity:0;transform:translate(-50%,-12px) scale(.94)}to{opacity:1;transform:translate(-50%,0) scale(1)}}" +
      "@keyframes fs-spin{to{transform:rotate(1turn)}}" +
      "@keyframes fs-shim{0%{background-position:-180% 0,0 0}100%{background-position:180% 0,0 0}}" +
      "#" + ID + "{position:fixed;left:50%;top:14px;z-index:2147483647;display:inline-flex;align-items:center;gap:8px;padding:8px 14px 8px 12px;border-radius:999px;" +
      'font:600 12px/1 "Nunito Sans",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;letter-spacing:.3px;color:#eef2ff;white-space:nowrap;pointer-events:none;' +
      "box-shadow:0 10px 30px rgba(0,0,0,.38),0 0 0 1px rgba(255,255,255,.08),inset 0 0 0 1px rgba(255,255,255,.06);" +
      "background:linear-gradient(110deg,rgba(255,255,255,0) 30%,rgba(255,255,255,.18) 50%,rgba(255,255,255,0) 70%),linear-gradient(135deg,#F5A524 0%,#FF6A3D 55%,#F5A524 100%);" +
      "background-size:240% 100%,100% 100%;background-repeat:no-repeat;transition:opacity .3s ease;animation:fs-in .28s cubic-bezier(.2,.8,.2,1) both,fs-shim 3.2s linear infinite}" +
      "#" + ID + "[data-state=done]{background:linear-gradient(135deg,#10b981 0%,#059669 100%);animation:fs-in .28s cubic-bezier(.2,.8,.2,1) both}" +
      "#" + ID + "[data-state=error]{background:linear-gradient(135deg,#b91c1c 0%,#ef4444 100%);animation:fs-in .28s cubic-bezier(.2,.8,.2,1) both}" +
      "#" + ID + " .avlr-spin{width:12px;height:12px;border-radius:50%;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;animation:fs-spin .7s linear infinite;display:inline-block}" +
      "#" + ID + " .avlr-ic{font-size:13px;line-height:1;display:inline-block}";
    (document.head || document.documentElement).appendChild(st);
  }

  let hideT = null;
  function apply(state) {
    try {
      ensureStyle();
      let el = document.getElementById(ID);
      if (!el) { el = document.createElement("div"); el.id = ID; (document.body || document.documentElement).appendChild(el); }
      if (state === "done") { el.setAttribute("data-state", "done"); el.innerHTML = '<span class="avlr-ic">✓</span><span>Proof-of-work solved</span>'; }
      else if (state === "error") { el.setAttribute("data-state", "error"); el.innerHTML = '<span class="avlr-ic">!</span><span>Proof-of-work failed</span>'; }
      else { el.removeAttribute("data-state"); el.innerHTML = '<span class="avlr-spin"></span><span>Solving proof-of-work…</span>'; }
      el.style.opacity = "1";
      if (hideT) { clearTimeout(hideT); hideT = null; }
      if (state !== "solving") {
        hideT = setTimeout(() => { try { el.style.opacity = "0"; setTimeout(() => { try { el.remove(); } catch (_) {} }, 320); } catch (_) {} }, 3000);
      }
    } catch (_) {}
  }

  // The solve is near-instant, so a raw solving->done would just flash. Hold "solving"
  // for a minimum so it's actually seen, THEN show done/error. This runs on the main
  // page (not the doomed frame), so the delayed transition always lands. A new "solving"
  // (next round) cancels a pending done, keeping the spinner up across a multi-round pow.
  const MIN_SOLVING_MS = 700;
  let solvingAt = 0, pendingT = null;
  function render(state) {
    if (pendingT) { clearTimeout(pendingT); pendingT = null; }
    if (state === "solving") { solvingAt = Date.now(); apply("solving"); return; }
    const wait = Math.max(0, MIN_SOLVING_MS - (Date.now() - solvingAt));
    if (wait > 0) pendingT = setTimeout(() => { pendingT = null; apply(state); }, wait);
    else apply(state);
  }

  window.addEventListener("message", (e) => {
    try {
      const d = e && e.data;
      if (!d || d.__avlrPowUI == null) return;
      // Only accept status from an Arkose/FunCaptcha frame.
      if (!/arkose|funcaptcha/i.test(e.origin || "")) return;
      render(String(d.__avlrPowUI));
    } catch (_) {}
  }, false);
})();
